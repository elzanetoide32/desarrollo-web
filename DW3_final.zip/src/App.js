import React, { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Link,
  Navigate,
} from "react-router-dom";
import UserList from "./UserList";
import UserForm from "./UserForm";
import UserEdit from "./UserEdit";
import UserDelete from "./UserDelete";

const App = () => {
  // Estado para almacenar la lista de usuarios
  const [users, setUsers] = useState([]);

  // Función para agregar un nuevo usuario
  const addUser = async (newUser) => {
    try {
      const response = await fetch(
        "https://6637830e288fedf6938084ea.mockapi.io/users",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(newUser),
        }
      );

      if (response.ok) {
        // Redirigir a la lista de usuarios después de agregar uno nuevo
        window.location.href = "/";
      } else {
        console.error("Error al agregar usuario");
      }
    } catch (error) {
      console.error("Error en la solicitud: ", error);
    }
  };

  // Cargar la lista de usuarios cuando el componente se monte
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch(
          "https://6637830e288fedf6938084ea.mockapi.io/users"
        );
        if (response.ok) {
          const data = await response.json();
          setUsers(data);
        } else {
          console.error("Error al cargar usuarios");
        }
      } catch (error) {
        console.error("Error en la solicitud: ", error);
      }
    };
    fetchUsers();
  }, []);

  return (
    <Router>
      <div>
        <nav style={{ backgroundColor: "#333", padding: "10px" }}>
          <ul
            style={{
              display: "flex",
              justifyContent: "center",
              listStyleType: "none",
              margin: 0,
              padding: 0,
            }}
          >
            <li style={{ margin: "0 10px" }}>
              <Link to="/" style={{ color: "#fff", textDecoration: "none" }}>
                Usuarios
              </Link>
            </li>
            <li style={{ margin: "0 10px" }}>
              <Link
                to="/create"
                style={{ color: "#fff", textDecoration: "none" }}
              >
                Crear Usuario
              </Link>
            </li>
            <li style={{ margin: "0 10px" }}>
              <Link
                to="/edit"
                style={{ color: "#fff", textDecoration: "none" }}
              >
                Editar Usuario
              </Link>
            </li>
            <li style={{ margin: "0 10px" }}>
              <Link
                to="/delete"
                style={{ color: "#fff", textDecoration: "none" }}
              >
                Eliminar Usuario
              </Link>
            </li>
          </ul>
        </nav>

        <Routes>
          <Route path="/" element={<UserList users={users} />} />
          <Route path="/create" element={<UserForm addUser={addUser} />} />
          <Route path="/edit/" element={<UserEdit users={users} />} />
          <Route path="/delete/" element={<UserDelete users={users} />} />
          {/* Redirección por defecto a la lista de usuarios */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
