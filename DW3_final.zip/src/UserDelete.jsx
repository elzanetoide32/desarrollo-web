import React, { useState } from "react";

const UserDelete = () => {
  const [userName, setUserName] = useState("");
  const [user, setUser] = useState(null);

  const fetchUserDetails = async () => {
    try {
      const response = await fetch(
        `https://6637830e288fedf6938084ea.mockapi.io/users?search=${userName}`
      );
      if (!response.ok) {
        throw new Error("No se pudo cargar los detalles del usuario.");
      }
      const data = await response.json();
      if (data.length === 0) {
        throw new Error("Usuario no encontrado.");
      }
      setUser(data[0]);
    } catch (error) {
      console.error("Error en la solicitud: ", error);
    }
  };

  const handleDelete = async () => {
    try {
      if (!user) {
        throw new Error("Primero debes buscar un usuario.");
      }
      const confirmDelete = window.confirm(
        `¿Estás seguro de que deseas eliminar a ${user.name}?`
      );
      if (!confirmDelete) return; // Si el usuario cancela, no se elimina el usuario

      const response = await fetch(
        `https://6637830e288fedf6938084ea.mockapi.io/users/${user.id}`,
        {
          method: "DELETE",
        }
      );
      if (!response.ok) {
        throw new Error("No se pudo eliminar el usuario.");
      }
      console.log("Usuario eliminado con éxito");
    } catch (error) {
      console.error("Error en la solicitud: ", error);
    }
  };

  return (
    <div>
      <h1>Eliminar Usuario</h1>
      <input
        type="text"
        value={userName}
        onChange={(e) => setUserName(e.target.value)}
        placeholder="Nombre del usuario"
        style={{
          backgroundColor: "#f0f0f0",
          padding: "5px",
          borderRadius: "5px",
          border: "1px solid #ccc",
        }}
      />
      <button
        onClick={fetchUserDetails}
        style={{
          backgroundColor: "#007bff",
          color: "#fff",
          padding: "10px 20px",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
        }}
      >
        Buscar Usuario
      </button>
      {user && (
        <div>
          <p>¿Estás seguro de que deseas eliminar a {user.name}?</p>
          <button onClick={handleDelete}>Eliminar</button>
        </div>
      )}
    </div>
  );
};

export default UserDelete;
