import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const UserEdit = () => {
  const [user, setUser] = useState({});
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetchUserDetails();
  }, []);

  const fetchUserDetails = async () => {
    try {
      const response = await fetch(
        `https://6637830e288fedf6938084ea.mockapi.io/users?search=${name}`
      );
      if (!response.ok) {
        throw new Error("No se pudo cargar los detalles del usuario.");
      }
      const data = await response.json();
      if (data.length === 0) {
        throw new Error("Usuario no encontrado.");
      }
      setUser(data[0]);
      setName(data[0].name);
      setEmail(data[0].email);
    } catch (error) {
      console.error("Error en la solicitud: ", error);
      // Aquí podrías manejar el error, por ejemplo, mostrando un mensaje al usuario
    }
  };

  const handleUpdate = async () => {
    try {
      const response = await fetch(
        `https://6637830e288fedf6938084ea.mockapi.io/users/${user.id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ name, email }), // Actualizamos tanto el nombre como el correo electrónico
        }
      );
      if (!response.ok) {
        throw new Error("No se pudo actualizar el usuario.");
      }
      navigate(`/users/${user.id}`);
    } catch (error) {
      console.error("Error en la solicitud: ", error);
      // Aquí podrías manejar el error, por ejemplo, mostrando un mensaje al usuario
    }
  };

  return (
    <div>
      <h1>Editar Usuario</h1>
      <label>Nombre: </label>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        style={{
          backgroundColor: "#f0f0f0",
          padding: "5px",
          borderRadius: "5px",
          border: "1px solid #ccc",
        }}
      />
      <br />
      <label>Email: </label>
      <input
        type="text"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        style={{
          backgroundColor: "#f0f0f0",
          padding: "5px",
          borderRadius: "5px",
          border: "1px solid #ccc",
        }}
      />
      <br />
      <button
        onClick={handleUpdate}
        style={{
          backgroundColor: "#007bff",
          color: "#fff",
          padding: "10px 20px",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
        }}
      >
        Actualizar
      </button>
    </div>
  );
};

export default UserEdit;
